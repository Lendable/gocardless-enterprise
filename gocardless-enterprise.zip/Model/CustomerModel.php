<?php
/**
 * Created by PhpStorm.
 * User: Paul
 * Date: 07/08/14
 * Time: 17:08
 */

namespace Alpha\Gocardless\Model;

class CustomerModel {

    private $id;
    private $email;
    private $givenName;
    private $familyName;

    function __construct($email, $familyName, $givenName)
    {
        $this->email = $email;
        $this->familyName = $familyName;
        $this->givenName = $givenName;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $id;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $familyName
     */
    public function setFamilyName($familyName)
    {
        $this->familyName = $familyName;
    }

    /**
     * @return mixed
     */
    public function getFamilyName()
    {
        return $this->familyName;
    }

    /**
     * @param mixed $givenName
     */
    public function setGivenName($givenName)
    {
        $this->givenName = $givenName;
    }

    /**
     * @return mixed
     */
    public function getGivenName()
    {
        return $this->givenName;
    }


}