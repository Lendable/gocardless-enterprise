<?php
/**
 * Created by PhpStorm.
 * User: Paul
 * Date: 06/08/14
 * Time: 17:33
 */

namespace Alpha\Gocardless;


use Alpha\Gocardless\Model\CustomerModel;
use Guzzle\Http\Client;

class GoCardlessEnterprise
{
    /**
     * @var \Guzzle\Http\Client
     */
    protected $client;

    /**
     * @var array
     */
    protected $config;

    /**
     * @var array
     */
    protected $endpoints = [
        "customer" => "customers",
        "bank" => "customer_bank_accounts",
        "mandate" => "mandates",
        "payments" => "payments"
    ];

    /**
     * @param Client $client
     * @param array $config
     */
    public function __construct(Client $client, array $config)
    {
        $this->client = $client;
        $this->config = $config;
    }

    public function createCustomer(CustomerModel $customer)
    {
        $url = $this->config['baseUrl'] . '/customer';
        $response = $this->client->post($url, $customer->toJson());
        if (!$response->isOk())
        {
            throw new
        }
} 